<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.sportsclub.model.Member" %>
<%
    Member currentMember = (Member) session.getAttribute("currentMember");
    if (currentMember == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
    <h2>Welcome, <%= currentMember.getName() %></h2>

    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>

    <ul>
        <li><a href="facilities">Browse Facilities</a></li>
        <li><a href="myBookings">My Bookings</a></li>
        <li><a href="buyMembership">Buy Membership</a></li>
        <li><a href="logout">Logout</a></li>
    </ul>
</body>
</html>