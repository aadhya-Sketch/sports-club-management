<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.sportsclub.model.Facility" %>
<!DOCTYPE html>
<html>
<head><title>Facilities</title></head>
<body>
    <h2>Facilities</h2>
    <ul>
        <% 
            List<Facility> facilities = (List<Facility>) request.getAttribute("facilities");
            for (Facility f : facilities) {
        %>
            <li>
                <%= f.getFacilityName() %> (<%= f.getFacilityType() %>)
                — <a href="units?facilityId=<%= f.getFacilityId() %>">View Units</a>
            </li>
        <% } %>
    </ul>
    <p><a href="dashboard">Back to Dashboard</a></p>
</body>
</html>