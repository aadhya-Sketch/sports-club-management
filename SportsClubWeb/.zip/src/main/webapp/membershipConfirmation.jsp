<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Membership Confirmed</title></head>
<body>
    <h2>Membership Purchased!</h2>
    <p>Type: <%= request.getAttribute("membershipType") %></p>
    <p>Amount: Rs. <%= request.getAttribute("amount") %></p>
    <p>Valid Until: <%= request.getAttribute("endDate") %></p>
    <p><%= request.getAttribute("paymentResult") %></p>
    <p><a href="dashboard">Back to Dashboard</a></p>
</body>
</html>