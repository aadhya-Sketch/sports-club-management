<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Verify Email</title></head>
<body>
    <h2>Enter Verification Code</h2>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
    <form action="verifyOtp" method="post">
        <label>Code sent to your email:</label><br>
        <input type="text" name="otp" required><br><br>

        <label>Create Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Complete Registration</button>
    </form>
</body>
</html>