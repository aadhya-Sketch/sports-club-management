<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Buy Membership</title></head>
<body>
    <h2>Buy Membership</h2>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
    <form action="buyMembership" method="post">
        <label>Membership Type:</label><br>
        <select name="membershipType" required>
            <option value="Monthly">Monthly — Rs. 500</option>
            <option value="Quarterly">Quarterly — Rs. 1000</option>
            <option value="Yearly">Yearly — Rs. 1500</option>
        </select><br><br>

        <label>Start Date:</label><br>
        <input type="date" name="startDate" required><br><br>

        <label>Payment Method:</label><br>
        <select name="paymentMethod" required>
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
            <option value="UPI">UPI</option>
            <option value="Net Banking">Net Banking</option>
        </select><br><br>

        <button type="submit">Purchase</button>
    </form>
    <p><a href="dashboard">Back to Dashboard</a></p>
</body>
</html>