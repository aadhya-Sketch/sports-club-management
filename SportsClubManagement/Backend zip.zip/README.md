# Automated Sports Club Management System

A console-based Java application to manage bookings, memberships, and payments 
for a sports complex — built with Java, JDBC, and MySQL.

## Features
- Member registration and login
- Browse facilities (Tennis, Badminton, Multi-purpose, Archery) and their units
- Book a facility slot (1-hour fixed duration) — only available to members with 
  an active, non-expired membership
- Prevents double-booking of the same unit at the same date/time
- Cancel an existing booking
- Purchase a membership (Monthly ₹500 / Quarterly ₹1000 / Yearly ₹1500)
- Payment recording for both bookings (₹300 flat) and memberships, with 
  selectable payment method (Cash / Card / UPI / Net Banking)

## Tech Stack
- Java (JDK 17+)
- JDBC (MySQL Connector/J)
- MySQL 8
- Eclipse IDE

## Database Setup
1. Open MySQL Workbench and create the database:
```sql
   CREATE DATABASE sports_club_db;
```
2. Run the table creation scripts from `database/schema.sql` (see note below).
3. Update the credentials in `com.sportsclub.db.DBConnection.java`:
```java
   private static final String URL = "jdbc:mysql://localhost:3306/sports_club_db";
   private static final String USER = "root";
   private static final String PASSWORD = "your_password";
```

## How to Run
1. Import the project into Eclipse (or open it if already there).
2. Make sure the MySQL Connector/J jar is added to the build path.
3. Make sure your MySQL server is running.
4. Run `com.sportsclub.main.App.java` as a Java Application.
5. Follow the on-screen menu to register, log in, and use the system.

## Project Structure

src/
└── com.sportsclub/
├── db/ → DBConnection.java (JDBC connection setup)
├── model/ → Member, Facility, FacilityUnit, Booking, Membership, Payment
├── dao/ → MemberDAO, FacilityDAO, BookingDAO, MembershipDAO, PaymentDAO
└── main/ → App.java (console menu + entry point)


## Database Tables
- **members** — registered users
- **facilities** — facility types (Tennis, Badminton, Multi-purpose, Archery)
- **facilities_units** — individual bookable units (e.g., Tennis Court 1)
- **bookings** — booking records, 1-hour slots
- **memberships** — membership plans and validity
- **payments** — payment transactions for bookings and memberships

##Author
Aadhya B N
Anudeep Foundation